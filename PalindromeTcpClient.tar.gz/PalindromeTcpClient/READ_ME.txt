To compile the project, you need to set up Maven.

How to setup maven with IntelliJ IDEA:
https://www.youtube.com/watch?v=pt3uB0sd5kY

To run the program, run command;
java -jar PalindromeTcpClient/target/palindrome-tcp-client-1.0-SNAPSHOT.jar